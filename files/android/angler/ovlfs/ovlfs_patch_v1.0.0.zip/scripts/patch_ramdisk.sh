#!/tmp/busybox sh

mkdir /tmp/ramdisk
cd /tmp/ramdisk/
/tmp/busybox gunzip -c /tmp/boot.img-ramdisk.gz | /tmp/busybox cpio -i
rm /tmp/boot.img-ramdisk.gz

#Don't force encryption
if  grep -qr forceencrypt /tmp/ramdisk/fstab.angler; then
   sed -i "s/forceencrypt/encryptable/" /tmp/ramdisk/fstab.angler
fi

#Disable dm_verity
if  grep -qr verify=/dev/block/platform/msm_sdcc.1/by-name/metadata /tmp/ramdisk/fstab.angler; then
   sed -i "s/\,verify\=\/dev\/block\/platform\/msm_sdcc\.1\/by\-name\/metadata//" /tmp/ramdisk/fstab.angler
fi
if  grep -qr verify=/dev/block/platform/soc.0/f9824900.sdhci/by-name/metadata /tmp/ramdisk/fstab.angler; then
   sed -i "s/\,verify\=\/dev\/block\/platform\/soc\.0\/f9824900\.sdhci\/by\-name\/metadata//" /tmp/ramdisk/fstab.angler
fi

rm /tmp/ramdisk/verity_key

#Change mount points for system and vendor
if [ $(grep -c "/ovlfs/system/ro" /tmp/ramdisk/init.rc) == 0 ]; then
   sed -i "s/\/system/\/ovlfs\/system\/ro/2" /tmp/ramdisk/fstab.angler
fi
if [ $(grep -c "/ovlfs/vendor/ro" /tmp/ramdisk/init.rc) == 0 ]; then
   sed -i "s/\/vendor/\/ovlfs\/vendor\/ro/2" /tmp/ramdisk/fstab.angler
fi

#Start ovlfs script
if [ $(grep -c "import /init.ovlfs.rc" /tmp/ramdisk/init.rc) == 0 ]; then
   sed -i "/import \/init\.trace\.rc/aimport /init.ovlfs.rc" /tmp/ramdisk/init.rc
fi

#copy ovlfs scripts
cp /tmp/init.ovlfs.rc /tmp/ramdisk/init.ovlfs.rc
chmod 755 /tmp/ramdisk/init.ovlfs.rc

#patch sepolicy with ovlfs support
cp /tmp/ramdisk/sepolicy /tmp/ramdisk/sepolicy_patched
/tmp/ovlfs-inject /tmp/ramdisk/sepolicy /tmp/ramdisk/sepolicy_patched
cp /tmp/ramdisk/sepolicy_patched /tmp/ramdisk/sepolicy
rm /tmp/ramdisk/sepolicy_patched

#add entries for ovlfs/system layer
#echo "#############################" >  /tmp/file_ovlfs_contexts
#echo "# Ovlfs files" >>  /tmp/file_ovlfs_contexts
#echo "#" >>  /tmp/file_ovlfs_contexts
#echo "/data/ovlfs(/.*)?			u:object_r:media_rw_data_file:s0" >>  /tmp/file_ovlfs_contexts
#echo "/data/ovlfs/system(/.*)?		u:object_r:media_rw_data_file:s0" >>  /tmp/file_ovlfs_contexts
#echo "/data/ovlfs/system/work(/.*)?	u:object_r:media_rw_data_file:s0" >>  /tmp/file_ovlfs_contexts
#echo "/data/ovlfs/vendor(/.*)?		u:object_r:media_rw_data_file:s0" >>  /tmp/file_ovlfs_contexts
#echo "/data/ovlfs/vendor/work(/.*)?	u:object_r:media_rw_data_file:s0" >>  /tmp/file_ovlfs_contexts
#echo "#############################" >>  /tmp/file_ovlfs_contexts
#echo "# Ovlfs System files" >>  /tmp/file_ovlfs_contexts
#echo "#" >>  /tmp/file_ovlfs_contexts
#sed -n '/^\/system/p' /tmp/ramdisk/file_contexts  | sed "s/\/system/\/data\/ovlfs\/system\/upper/g" >> /tmp/file_ovlfs_contexts
#echo "#############################" >>  /tmp/file_ovlfs_contexts
#echo "# Ovlfs Vendor files" >>  /tmp/file_ovlfs_contexts
#echo "#" >>  /tmp/file_ovlfs_contexts
#sed -n '/^\/vendor/p' /tmp/ramdisk/file_contexts  | sed "s/\/vendor/\/data\/ovlfs\/vendor\/upper/g" >> /tmp/file_ovlfs_contexts
#cat /tmp/file_ovlfs_contexts >> /tmp/ramdisk/file_contexts

#edit policy for sesuperuser. Note: supersu is crashing at daemonsu
/tmp/sepolicy-inject -z su_daemon -P sepolicy
/tmp/sepolicy-inject -s su_daemon -t zygote_exec -c file -p getattr -P /tmp/ramdisk/sepolicy
/tmp/sepolicy-inject -s su_daemon -t toolbox_exec -c file -p getattr -P /tmp/ramdisk/sepolicy
/tmp/sepolicy-inject -s su_daemon -t shell_exec -c file -p getattr -P /tmp/ramdisk/sepolicy

/tmp/busybox cp /tmp/ramdisk/system /tmp/ramdisk/vendor -rapf
/tmp/busybox rm -rf /tmp/ramdisk/vendor/*

/tmp/busybox find . | /tmp/busybox cpio -o -H newc | /tmp/busybox gzip > /tmp/boot.img-ramdisk.gz
#rm -r /tmp/ramdisk 

