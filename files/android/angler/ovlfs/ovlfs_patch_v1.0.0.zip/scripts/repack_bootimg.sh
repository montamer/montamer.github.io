#!/tmp/busybox sh
echo \#!/tmp/busybox sh > /tmp/createnewboot.sh
echo /tmp/mkbootimg --kernel /tmp/kernel --ramdisk /tmp/boot.img-ramdisk.gz --cmdline \"$(cat /tmp/boot.img-cmdline)\" --base $(cat /tmp/boot.img-base) --kernel_offset 0x00008000 --pagesize $(cat /tmp/boot.img-pagesize) --ramdisk_offset 0x02000000 --tags_offset 0x01e00000 --output /tmp/boot_new.img >> /tmp/createnewboot.sh
chmod 777 /tmp/createnewboot.sh
/tmp/createnewboot.sh
return $?

